/**
 * @version     CVS: 1.0.6
 * @package     com_astronomer
 * @subpackage  mod_astronomer
 * @copyright   2016 Troy Hall & Arkansas Sky Observatory
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Troy "Bear" Hall <webmaster@arksky.org>
 */



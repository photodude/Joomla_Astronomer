/**
 * @version     CVS: 1.0.5
 * @package     com_astronomer
 * @subpackage  mod_astronomer
 * @copyright   2016 Troy Hall
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Troy Hall <troy@jowwow.net>
 */



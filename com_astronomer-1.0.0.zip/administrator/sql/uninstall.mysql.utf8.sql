DROP TABLE IF EXISTS `#__joomla_astronomer`;

DELETE FROM `#__content_types` WHERE (type_alias LIKE 'com_astronomer.%');